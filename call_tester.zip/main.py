from flask import Flask, request, jsonify, render_template, redirect, url_for, send_file, Response
from providers.twilio_provider import TwilioProvider
from dotenv import load_dotenv
import threading
import time
import csv
import os
from openpyxl import Workbook

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

# Twilio credentials and configuration
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN')
TWILIO_NUMBER = os.getenv('TWILIO_NUMBER')
DOMAIN = os.getenv('DOMAIN')  # e.g., https://ivrtech.org

# Callback URLs
CALLBACK_URL = f'{DOMAIN}/call_back_url/handle_call'
STATUS_CALLBACK_URL = f'{DOMAIN}/call_back_url/status_callback'

# Initialize the provider
provider = TwilioProvider(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# Dictionary to store call results
call_results = {}
# Lock for thread-safe updates to call_results
lock = threading.Lock()

# Function to read phone numbers from a text file
def read_phone_numbers(file_path):
    with open(file_path, 'r') as f:
        numbers = [line.strip() for line in f if line.strip()]
    return numbers

# Function to initiate calls
def start_call_tests(phone_numbers):
    for number in phone_numbers:
        try:
            call_sid = provider.initiate_call(
                to_number=number,
                from_number=TWILIO_NUMBER,
                callback_url=CALLBACK_URL,
                status_callback_url=STATUS_CALLBACK_URL
            )
            print(f'Initiated call to {number}, Call SID: {call_sid}')
            time.sleep(1)  # Sleep to respect rate limits
        except Exception as e:
            print(f'Error initiating call to {number}: {{str(e)}}')
            with lock:
                call_results[number] = f'Error: {{str(e)}}'

# Route to render the index page
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle file upload
@app.route('/upload_numbers', methods=['POST'])
def upload_numbers():
    global call_results
    # Reset previous results
    with lock:
        call_results = {}
    # Check if the post request has the file part
    if 'numbers_file' not in request.files:
        return 'No file part', 400
    file = request.files['numbers_file']
    # If user does not select file, browser may submit an empty part without filename
    if file.filename == '':
        return 'No selected file', 400
    if file and file.filename.endswith('.txt'):
        # Save the file to the uploads directory
        upload_path = os.path.join('uploads', file.filename)
        file.save(upload_path)
        # Read phone numbers from the uploaded file
        phone_numbers = read_phone_numbers(upload_path)
        # Start the call tests in a separate thread
        threading.Thread(target=start_call_tests, args=(phone_numbers,)).start()
        return redirect(url_for('results'))
    else:
        return 'Invalid file format. Please upload a .txt file.', 400

# Route to display results
@app.route('/results')
def results():
    return render_template('results.html', results=call_results)

# Route to download results as CSV
@app.route('/download_results_csv')
def download_results_csv():
    csv_file = 'call_results.csv'
    with open(csv_file, 'w', newline='') as csvfile:
        fieldnames = ['Phone Number', 'Status']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        with lock:
            for number, status in call_results.items():
                writer.writerow({'Phone Number': number, 'Status': status})
    return send_file(csv_file, as_attachment=True)

# Route to download results as XLSX
@app.route('/download_results_xlsx')
def download_results_xlsx():
    xlsx_file = 'call_results.xlsx'
    wb = Workbook()
    ws = wb.active
    ws.append(['Phone Number', 'Status'])
    with lock:
        for number, status in call_results.items():
            ws.append([number, status])
    wb.save(xlsx_file)
    return send_file(xlsx_file, as_attachment=True)

# Endpoint to handle incoming call instructions (Twilio will request this URL)
@app.route('/call_back_url/handle_call', methods=['POST'])
def handle_call():
    response = '''<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Hangup/>
</Response>
'''
    return Response(response, mimetype='application/xml')

# Endpoint to handle call status callbacks
@app.route('/call_back_url/status_callback', methods=['POST'])
def status_callback():
    call_sid = request.form.get('CallSid')
    call_status = request.form.get('CallStatus')
    to_number = request.form.get('To')

    print(f'Call SID: {{call_sid}}, Status: {{call_status}}, To: {{to_number}}')

    if call_status == 'ringing':
        # Number is reachable; hang up the call
        try:
            provider.hangup_call(call_sid)
            with lock:
                call_results[to_number] = 'Reachable'
        except Exception as e:
            print(f'Error hanging up call {{call_sid}}: {{str(e)}}')
            with lock:
                call_results[to_number] = f'Error: {{str(e)}}'
    elif call_status in ['failed', 'busy', 'no-answer', 'canceled']:
        with lock:
            call_results[to_number] = 'Unreachable'
    elif call_status == 'answered':
        # Call was answered; mark as answered
        with lock:
            call_results[to_number] = 'Answered'
    elif call_status == 'completed':
        # Call was completed
        pass

    return ('', 204)

if __name__ == '__main__':
    # Ensure uploads directory exists
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)
