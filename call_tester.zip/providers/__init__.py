from abc import ABC, abstractmethod

class ProviderInterface(ABC):
    @abstractmethod
    def initiate_call(self, to_number, from_number, callback_url, status_callback_url):
        pass

    @abstractmethod
    def hangup_call(self, call_sid):
        pass
