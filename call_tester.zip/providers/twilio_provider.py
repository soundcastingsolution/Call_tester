import requests
from providers import ProviderInterface

class TwilioProvider(ProviderInterface):
    def __init__(self, account_sid, auth_token):
        self.account_sid = account_sid
        self.auth_token = auth_token
        self.base_url = f'https://api.twilio.com/2010-04-01/Accounts/{self.account_sid}'

    def initiate_call(self, to_number, from_number, callback_url, status_callback_url):
        url = f'{self.base_url}/Calls.json'
        data = {
            'To': to_number,
            'From': from_number,
            'Url': callback_url,  # This URL tells Twilio what to do when the call is answered
            'StatusCallback': status_callback_url,
            'StatusCallbackEvent': ['initiated', 'ringing', 'answered', 'completed']
        }
        response = requests.post(url, data=data, auth=(self.account_sid, self.auth_token))
        if response.status_code == 201:
            call_sid = response.json().get('sid')
            return call_sid
        else:
            raise Exception(f'Failed to initiate call: {response.text}')

    def hangup_call(self, call_sid):
        url = f'{self.base_url}/Calls/{call_sid}.json'
        data = {
            'Status': 'completed'
        }
        response = requests.post(url, data=data, auth=(self.account_sid, self.auth_token))
        if response.status_code != 200:
            raise Exception(f'Failed to hang up call: {response.text}')
